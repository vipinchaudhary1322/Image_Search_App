import './App.css';
import ImageSearch from './components/imageSearch';

function App() {
  return (
    <div className="App">
      <ImageSearch/>
    </div>
  );
}

export default App;
