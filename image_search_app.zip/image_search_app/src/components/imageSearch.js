import React, { useState } from "react";
import axios from "axios";
import "./style.css"

function ImageSearch() {
  const [photo, setPhoto] = useState("");
  const [result, setResult] = useState([]);
  const [book,setBook]=useState([setResult])

  const changePhoto = () => {
    axios
      .get(
        `https://api.unsplash.com/search/photos?page=1&query=${photo}&client_id=HB9BIg2J-0zBpjT_t5sC826DnbWMA9FPQkIOtUUsRRU`
      )
      .then((response) => {
        setResult(response.data.results);
      });
  };
  const bookmarkPhoto=()=>{
           setBook([result])
  }
  return (
    <>
    <div ><h1>React Photo Search</h1><button className="btnn">Bookmark</button></div>
      <div className="container text-center my-5">
        <input
          type="text"
          className="form-control"
          value={photo}
          onChange={(e) => {
            setPhoto(e.target.value);
          }}
        />
        <button
          type="submit"
          onClick={changePhoto}
          className="btn btn-dark my-2"
        >
          Search
        </button>
      </div>

      <div className="container">
        <div class="row text-center text-lg-start">
          {result.map((value) => {
            return (
              <div className="flex" class=" col-md-4 col-3" >
                <img className="img" onClick={bookmarkPhoto}
                  class="img-fluid img-thumbnail d-block mb-4 h-100"
                  src={value.urls.small} value={book}
                  alt=""
                />
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
}

export default ImageSearch;
